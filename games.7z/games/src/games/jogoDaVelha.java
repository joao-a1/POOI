/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package games;

import java.awt.Color;
import javax.swing.JOptionPane;

public class jogoDaVelha extends javax.swing.JFrame {

    private String startGame = "X";
    private int xCount = 0;
    private int oCount = 0;
    
    public jogoDaVelha() {
        initComponents();
    }
    
    private void gameScore() {
        edtPlayerX.setText(String.valueOf(xCount));
        edtPlayerO.setText(String.valueOf(oCount));
    }
    
    private void choose_a_Player() {
        if (startGame.equalsIgnoreCase("X")) {
            startGame = "O";
            lblTurn.setText("Player O Turn");
        } else {
            startGame = "X";
            lblTurn.setText("Player X Turn");
        }
    }
    
    private void reset(){
        
        gameScore();
        
        btnButton1.setText("");
        btnButton2.setText("");
        btnButton3.setText("");
        btnButton4.setText("");
        btnButton5.setText("");
        btnButton6.setText("");
        btnButton7.setText("");
        btnButton8.setText("");
        btnButton9.setText("");
        
        btnButton1.setBackground(Color.LIGHT_GRAY);
        btnButton2.setBackground(Color.LIGHT_GRAY);
        btnButton3.setBackground(Color.LIGHT_GRAY);
        btnButton4.setBackground(Color.LIGHT_GRAY);
        btnButton5.setBackground(Color.LIGHT_GRAY);
        btnButton6.setBackground(Color.LIGHT_GRAY);
        btnButton7.setBackground(Color.LIGHT_GRAY);
        btnButton8.setBackground(Color.LIGHT_GRAY);
        btnButton9.setBackground(Color.LIGHT_GRAY);
        
        startGame = "O";
        choose_a_Player();

    }
    
    private void winningGame() {
        
        String btn1 = btnButton1.getText();
        String btn2 = btnButton2.getText();
        String btn3 = btnButton3.getText();

        String btn4 = btnButton4.getText();
        String btn5 = btnButton5.getText();
        String btn6 = btnButton6.getText();

        String btn7 = btnButton7.getText();
        String btn8 = btnButton8.getText();
        String btn9 = btnButton9.getText();
        
        // PLAYER X
        
        // HORIZONTAL
        
        if (btn1.equals("X") && btn2.equals("X") && btn3.equals("X")) {
            
            btnButton1.setBackground(Color.ORANGE);
            btnButton2.setBackground(Color.ORANGE);
            btnButton3.setBackground(Color.ORANGE);
            
            JOptionPane.showMessageDialog(this, "Player X Win", "Tic Tac Toe", 
                    JOptionPane.PLAIN_MESSAGE);
            xCount++;
            
            reset();

        }
        if (btn4.equals("X") && btn5.equals("X") && btn6.equals("X")) {
            
            btnButton4.setBackground(Color.ORANGE);
            btnButton5.setBackground(Color.ORANGE);
            btnButton6.setBackground(Color.ORANGE);
            
            JOptionPane.showMessageDialog(this, "Player X Win", "Tic Tac Toe", 
                    JOptionPane.PLAIN_MESSAGE);
            xCount++;
            
            reset();
            
        }
        if (btn7.equals("X") && btn8.equals("X") && btn9.equals("X")) {
            
            btnButton7.setBackground(Color.ORANGE);
            btnButton8.setBackground(Color.ORANGE);
            btnButton9.setBackground(Color.ORANGE);
            
            JOptionPane.showMessageDialog(this, "Player X Win", "Tic Tac Toe", 
                    JOptionPane.PLAIN_MESSAGE);
            xCount++;
            
            reset();
            
        }
        
        // VERTICAL
        
        if (btn1.equals("X") && btn4.equals("X") && btn7.equals("X")) {
            
            btnButton1.setBackground(Color.ORANGE);
            btnButton4.setBackground(Color.ORANGE);
            btnButton7.setBackground(Color.ORANGE);
            
            JOptionPane.showMessageDialog(this, "Player X Win", "Tic Tac Toe", 
                    JOptionPane.PLAIN_MESSAGE);
            xCount++;
            
            reset();
            
        }
        if (btn2.equals("X") && btn5.equals("X") && btn8.equals("X")) {
            
            btnButton2.setBackground(Color.ORANGE);
            btnButton5.setBackground(Color.ORANGE);
            btnButton8.setBackground(Color.ORANGE);
            
            JOptionPane.showMessageDialog(this, "Player X Win", "Tic Tac Toe", 
                    JOptionPane.PLAIN_MESSAGE);
            xCount++;
            
            reset();
            
        }
        if (btn3.equals("X") && btn6.equals("X") && btn9.equals("X")) {
            
            btnButton3.setBackground(Color.ORANGE);
            btnButton6.setBackground(Color.ORANGE);
            btnButton9.setBackground(Color.ORANGE);
            
            JOptionPane.showMessageDialog(this, "Player X Win", "Tic Tac Toe", 
                    JOptionPane.PLAIN_MESSAGE);
            xCount++;
            
            reset();
            
        }
        
        // DIAGONAL
        
        if (btn1.equals("X") && btn5.equals("X") && btn9.equals("X")) {
            
            btnButton1.setBackground(Color.ORANGE);
            btnButton5.setBackground(Color.ORANGE);
            btnButton9.setBackground(Color.ORANGE);
            
            JOptionPane.showMessageDialog(this, "Player X Win", "Tic Tac Toe", 
                    JOptionPane.PLAIN_MESSAGE);
            xCount++;
            
            reset();
            
        }
        if (btn3.equals("X") && btn5.equals("X") && btn7.equals("X")) {
           
            btnButton3.setBackground(Color.ORANGE);
            btnButton5.setBackground(Color.ORANGE);
            btnButton7.setBackground(Color.ORANGE);
            
            JOptionPane.showMessageDialog(this, "Player X Win", "Tic Tac Toe", 
                    JOptionPane.PLAIN_MESSAGE);
            xCount++;
            
            reset();
            
        }
        
        // PLAYER O
        
        // HORIZONTAL
        
         if (btn1.equals("O") && btn2.equals("O") && btn3.equals("O")) {
             
            btnButton1.setBackground(Color.ORANGE);
            btnButton2.setBackground(Color.ORANGE);
            btnButton3.setBackground(Color.ORANGE);
             
             JOptionPane.showMessageDialog(this, "Player O Win", "Tic Tac Toe", 
                    JOptionPane.PLAIN_MESSAGE);
            oCount++;
            
            reset();
            
        }
        if (btn4.equals("O") && btn5.equals("O") && btn6.equals("O")) {
            
            btnButton4.setBackground(Color.ORANGE);
            btnButton5.setBackground(Color.ORANGE);
            btnButton6.setBackground(Color.ORANGE);
             
             JOptionPane.showMessageDialog(this, "Player O Win", "Tic Tac Toe", 
                    JOptionPane.PLAIN_MESSAGE);
            oCount++;
            
            reset();
            
        }
        if (btn7.equals("O") && btn8.equals("O") && btn9.equals("O")) {
            
            btnButton7.setBackground(Color.ORANGE);
            btnButton8.setBackground(Color.ORANGE);
            btnButton9.setBackground(Color.ORANGE);
             
             JOptionPane.showMessageDialog(this, "Player O Win", "Tic Tac Toe", 
                    JOptionPane.PLAIN_MESSAGE);
            oCount++;
            
            reset();
            
        }
        
        // VERTICAL
        
        if (btn1.equals("O") && btn4.equals("O") && btn7.equals("O")) {
            
            btnButton1.setBackground(Color.ORANGE);
            btnButton4.setBackground(Color.ORANGE);
            btnButton7.setBackground(Color.ORANGE);
             
             JOptionPane.showMessageDialog(this, "Player O Win", "Tic Tac Toe", 
                    JOptionPane.PLAIN_MESSAGE);
            oCount++;
            
            reset();
            
        }
        if (btn2.equals("O") && btn5.equals("O") && btn8.equals("O")) {
            
            btnButton2.setBackground(Color.ORANGE);
            btnButton5.setBackground(Color.ORANGE);
            btnButton8.setBackground(Color.ORANGE);
             
             JOptionPane.showMessageDialog(this, "Player O Win", "Tic Tac Toe", 
                    JOptionPane.PLAIN_MESSAGE);
            oCount++;
            
            reset();
            
        }
        if (btn3.equals("O") && btn6.equals("O") && btn9.equals("O")) {
            
            btnButton3.setBackground(Color.ORANGE);
            btnButton6.setBackground(Color.ORANGE);
            btnButton9.setBackground(Color.ORANGE);
             
             JOptionPane.showMessageDialog(this, "Player O Win", "Tic Tac Toe", 
                    JOptionPane.PLAIN_MESSAGE);
            oCount++;
            
            reset();
            
        }
        
        // DIAGONAL
        
        if (btn1.equals("O") && btn5.equals("O") && btn9.equals("O")) {
            
            btnButton1.setBackground(Color.ORANGE);
            btnButton5.setBackground(Color.ORANGE);
            btnButton9.setBackground(Color.ORANGE);
             
             JOptionPane.showMessageDialog(this, "Player O Win", "Tic Tac Toe", 
                    JOptionPane.PLAIN_MESSAGE);
            oCount++;
            
            reset();
            
        }
        if (btn3.equals("O") && btn5.equals("O") && btn7.equals("O")) {
            
            btnButton3.setBackground(Color.ORANGE);
            btnButton5.setBackground(Color.ORANGE);
            btnButton7.setBackground(Color.ORANGE);
             
             JOptionPane.showMessageDialog(this, "Player O Win", "Tic Tac Toe", 
                    JOptionPane.PLAIN_MESSAGE);
            oCount++;
            
            reset();
            
        }
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel6 = new javax.swing.JPanel();
        btnExit = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        btnButton1 = new javax.swing.JButton();
        btnButton2 = new javax.swing.JButton();
        btnButton3 = new javax.swing.JButton();
        btnButton4 = new javax.swing.JButton();
        btnButton5 = new javax.swing.JButton();
        btnButton6 = new javax.swing.JButton();
        btnButton7 = new javax.swing.JButton();
        btnButton8 = new javax.swing.JButton();
        btnButton9 = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        lblTurn = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        lblPlayerX = new javax.swing.JLabel();
        lblPlayerO = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        edtPlayerX = new javax.swing.JLabel();
        edtPlayerO = new javax.swing.JLabel();
        btnResetScore = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        lblTitle = new javax.swing.JLabel();
        btnReset = new javax.swing.JButton();
        mnMenu = new javax.swing.JMenuBar();
        mnMenuReturn = new javax.swing.JMenu();
        mnBack = new javax.swing.JMenuItem();
        mnExit = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("TIC TAC TOE");
        setResizable(false);

        jPanel6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 204, 0), 4));

        btnExit.setBackground(new java.awt.Color(255, 0, 0));
        btnExit.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnExit.setForeground(new java.awt.Color(255, 0, 0));
        btnExit.setText("EXIT");
        btnExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExitActionPerformed(evt);
            }
        });

        jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder(java.awt.Color.lightGray, java.awt.Color.darkGray));

        btnButton1.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        btnButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnButton1ActionPerformed(evt);
            }
        });

        btnButton2.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        btnButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnButton2ActionPerformed(evt);
            }
        });

        btnButton3.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        btnButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnButton3ActionPerformed(evt);
            }
        });

        btnButton4.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        btnButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnButton4ActionPerformed(evt);
            }
        });

        btnButton5.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        btnButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnButton5ActionPerformed(evt);
            }
        });

        btnButton6.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        btnButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnButton6ActionPerformed(evt);
            }
        });

        btnButton7.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        btnButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnButton7ActionPerformed(evt);
            }
        });

        btnButton8.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        btnButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnButton8ActionPerformed(evt);
            }
        });

        btnButton9.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        btnButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnButton9ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(btnButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(btnButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnButton3, javax.swing.GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE)
                            .addComponent(btnButton6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(btnButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnButton9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnButton3, javax.swing.GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE)
                    .addComponent(btnButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnButton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnButton4, javax.swing.GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE)
                    .addComponent(btnButton6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnButton5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnButton8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(btnButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(btnButton9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        jPanel5.setBackground(new java.awt.Color(0, 0, 0));
        jPanel5.setBorder(javax.swing.BorderFactory.createEtchedBorder(java.awt.Color.lightGray, java.awt.Color.darkGray));

        lblTurn.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        lblTurn.setForeground(new java.awt.Color(255, 255, 255));
        lblTurn.setText("Player X Turn");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblTurn)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addComponent(lblTurn)
                .addGap(0, 5, Short.MAX_VALUE))
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.lightGray, java.awt.Color.darkGray));

        lblPlayerX.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        lblPlayerX.setForeground(new java.awt.Color(0, 204, 0));
        lblPlayerX.setText("Player X :");

        lblPlayerO.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        lblPlayerO.setForeground(new java.awt.Color(102, 0, 255));
        lblPlayerO.setText("Player O :");

        edtPlayerX.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        edtPlayerX.setText("xxxxxxxxxx");

        edtPlayerO.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        edtPlayerO.setText("xxxxxxxxxx");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(24, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(edtPlayerO)
                    .addComponent(edtPlayerX))
                .addGap(10, 10, 10))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addComponent(edtPlayerX)
                .addGap(30, 30, 30)
                .addComponent(jLabel1)
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(edtPlayerO))
        );

        btnResetScore.setBackground(new java.awt.Color(0, 0, 0));
        btnResetScore.setFont(new java.awt.Font("Segoe UI", 1, 11)); // NOI18N
        btnResetScore.setText("Reset Score");
        btnResetScore.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnResetScoreActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblPlayerO)
                    .addComponent(lblPlayerX))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnResetScore, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnResetScore, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                        .addComponent(lblPlayerX)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblPlayerO))
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(20, 20, 20))
        );

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));

        lblTitle.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        lblTitle.setForeground(new java.awt.Color(0, 204, 0));
        lblTitle.setText("TIC TAC TOE");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(131, 131, 131)
                .addComponent(lblTitle)
                .addContainerGap(138, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblTitle)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        btnReset.setBackground(new java.awt.Color(0, 0, 255));
        btnReset.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnReset.setForeground(new java.awt.Color(0, 0, 255));
        btnReset.setText("RESET");
        btnReset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnResetActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(72, 72, 72)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(btnReset, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(33, 33, 33)
                        .addComponent(btnExit, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(70, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 22, Short.MAX_VALUE)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnReset, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnExit, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10))
        );

        mnMenu.setBackground(new java.awt.Color(51, 51, 51));
        mnMenu.setForeground(new java.awt.Color(51, 51, 51));

        mnMenuReturn.setIcon(new javax.swing.ImageIcon("C:\\Users\\User\\Documents\\NetBeansProjects\\games\\options.png")); // NOI18N
        mnMenuReturn.setText("Options");

        mnBack.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_LEFT, java.awt.event.InputEvent.ALT_DOWN_MASK));
        mnBack.setIcon(new javax.swing.ImageIcon("C:\\Users\\User\\Documents\\NetBeansProjects\\games\\back.png")); // NOI18N
        mnBack.setText("Back");
        mnBack.setBorderPainted(true);
        mnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnBackActionPerformed(evt);
            }
        });
        mnMenuReturn.add(mnBack);

        mnExit.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F4, 0));
        mnExit.setIcon(new javax.swing.ImageIcon("C:\\Users\\User\\Documents\\NetBeansProjects\\games\\close.png")); // NOI18N
        mnExit.setText("Exit");
        mnExit.setBorderPainted(true);
        mnExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnExitActionPerformed(evt);
            }
        });
        mnMenuReturn.add(mnExit);

        mnMenu.add(mnMenuReturn);

        setJMenuBar(mnMenu);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnResetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnResetActionPerformed
        
        btnButton1.setText("");
        btnButton2.setText("");
        btnButton3.setText("");

        btnButton4.setText("");
        btnButton5.setText("");
        btnButton6.setText("");

        btnButton7.setText("");
        btnButton8.setText("");
        btnButton9.setText("");

        btnButton1.setBackground(Color.LIGHT_GRAY);
        btnButton2.setBackground(Color.LIGHT_GRAY);
        btnButton3.setBackground(Color.LIGHT_GRAY);

        btnButton4.setBackground(Color.LIGHT_GRAY);
        btnButton5.setBackground(Color.LIGHT_GRAY);
        btnButton6.setBackground(Color.LIGHT_GRAY);

        btnButton7.setBackground(Color.LIGHT_GRAY);
        btnButton8.setBackground(Color.LIGHT_GRAY);
        btnButton9.setBackground(Color.LIGHT_GRAY);

        startGame = "O";
        choose_a_Player();

    }//GEN-LAST:event_btnResetActionPerformed
    private void Exit(){
        Object[] obj = {"Sim", "Não"};

        if (JOptionPane.showOptionDialog(this, "Deseja realmente sair?", "Sair", JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE, null, obj, obj[0]) == JOptionPane.YES_NO_OPTION) {
        System.exit(0);
        }
    }
    
    private void btnExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExitActionPerformed
        Exit();
    }//GEN-LAST:event_btnExitActionPerformed

    private void mnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnBackActionPerformed
        lobby frame = new lobby();
        frame.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_mnBackActionPerformed

    private void mnExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnExitActionPerformed
        Exit();
    }//GEN-LAST:event_mnExitActionPerformed

    private void btnButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnButton9ActionPerformed
        btnButton9.setText(startGame);

        if (startGame.equalsIgnoreCase("X")) {
            btnButton9.setForeground(Color.RED);
        } else {
            btnButton9.setForeground(Color.MAGENTA);
        }

        choose_a_Player();
        winningGame();
    }//GEN-LAST:event_btnButton9ActionPerformed

    private void btnButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnButton8ActionPerformed
        btnButton8.setText(startGame);

        if (startGame.equalsIgnoreCase("X")) {
            btnButton8.setForeground(Color.RED);
        } else {
            btnButton8.setForeground(Color.MAGENTA);
        }

        choose_a_Player();
        winningGame();
    }//GEN-LAST:event_btnButton8ActionPerformed

    private void btnButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnButton7ActionPerformed
        btnButton7.setText(startGame);

        if (startGame.equalsIgnoreCase("X")) {
            btnButton7.setForeground(Color.RED);
        } else {
            btnButton7.setForeground(Color.MAGENTA);
        }

        choose_a_Player();
        winningGame();
    }//GEN-LAST:event_btnButton7ActionPerformed

    private void btnButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnButton6ActionPerformed
        btnButton6.setText(startGame);

        if (startGame.equalsIgnoreCase("X")) {
            btnButton6.setForeground(Color.RED);
        } else {
            btnButton6.setForeground(Color.MAGENTA);
        }

        choose_a_Player();
        winningGame();
    }//GEN-LAST:event_btnButton6ActionPerformed

    private void btnButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnButton5ActionPerformed
        btnButton5.setText(startGame);

        if (startGame.equalsIgnoreCase("X")) {
            btnButton5.setForeground(Color.RED);
        } else {
            btnButton5.setForeground(Color.MAGENTA);
        }

        choose_a_Player();
        winningGame();
    }//GEN-LAST:event_btnButton5ActionPerformed

    private void btnButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnButton4ActionPerformed
        btnButton4.setText(startGame);

        if (startGame.equalsIgnoreCase("X")) {
            btnButton4.setForeground(Color.RED);
        } else {
            btnButton4.setForeground(Color.MAGENTA);
        }

        choose_a_Player();
        winningGame();
    }//GEN-LAST:event_btnButton4ActionPerformed

    private void btnButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnButton3ActionPerformed
        btnButton3.setText(startGame);

        if (startGame.equalsIgnoreCase("X")) {
            btnButton3.setForeground(Color.RED);
        } else {
            btnButton3.setForeground(Color.MAGENTA);
        }

        choose_a_Player();
        winningGame();
    }//GEN-LAST:event_btnButton3ActionPerformed

    private void btnButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnButton2ActionPerformed
        btnButton2.setText(startGame);

        if (startGame.equalsIgnoreCase("X")) {
            btnButton2.setForeground(Color.RED);
        } else {
            btnButton2.setForeground(Color.MAGENTA);
        }

        choose_a_Player();
        winningGame();
    }//GEN-LAST:event_btnButton2ActionPerformed

    private void btnButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnButton1ActionPerformed

        btnButton1.setText(startGame);

        if (startGame.equalsIgnoreCase("X")) {
            btnButton1.setForeground(Color.RED);
        } else {
            btnButton1.setForeground(Color.MAGENTA);
        }

        choose_a_Player();
        winningGame();
    }//GEN-LAST:event_btnButton1ActionPerformed

    private void btnResetScoreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnResetScoreActionPerformed
        xCount = 0;
        oCount = 0;

        edtPlayerX.setText("xxxxxxxxxx");
        edtPlayerO.setText("xxxxxxxxxx");
    }//GEN-LAST:event_btnResetScoreActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            javax.swing.UIManager.setLookAndFeel(javax.swing.UIManager.getSystemLookAndFeelClassName());
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(jogoDaVelha.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(jogoDaVelha.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(jogoDaVelha.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(jogoDaVelha.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new jogoDaVelha().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnButton1;
    private javax.swing.JButton btnButton2;
    private javax.swing.JButton btnButton3;
    private javax.swing.JButton btnButton4;
    private javax.swing.JButton btnButton5;
    private javax.swing.JButton btnButton6;
    private javax.swing.JButton btnButton7;
    private javax.swing.JButton btnButton8;
    private javax.swing.JButton btnButton9;
    private javax.swing.JButton btnExit;
    private javax.swing.JButton btnReset;
    private javax.swing.JButton btnResetScore;
    private javax.swing.JLabel edtPlayerO;
    private javax.swing.JLabel edtPlayerX;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JLabel lblPlayerO;
    private javax.swing.JLabel lblPlayerX;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JLabel lblTurn;
    private javax.swing.JMenuItem mnBack;
    private javax.swing.JMenuItem mnExit;
    private javax.swing.JMenuBar mnMenu;
    private javax.swing.JMenu mnMenuReturn;
    // End of variables declaration//GEN-END:variables
}
